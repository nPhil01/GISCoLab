$(document).on('click', '#codenav', function(e){
    e.preventDefault();
    $.ajax('rcode.html', {
        success: function(response){{
            $('#currentload').html(response);
            $('.active:last').removeClass('active');
            $('#codenav').addClass('active');
        }}
    })
})

$(document).on('click', '#searchnav', function(e){
    e.preventDefault();
    $.ajax('searchcurrent.html', {
        success: function(response){{
            $('#currentload').html(response);
            $('.active:last').removeClass('active');
            $('#searchnav').addClass('active');
        }}
    })
})